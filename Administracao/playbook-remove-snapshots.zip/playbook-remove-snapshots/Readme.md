.
├── playbook-remove-snapshots.yml
├── files/
│   └── notify.sh  (exemplo de script de notificação)
├── group_vars/
│   └── all.yml    (variáveis globais)
